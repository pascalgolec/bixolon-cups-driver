#!/bin/sh

#64bit
rpm -ivh Star_CUPS_Driver-3.17.0-1.x86_64.rpm
